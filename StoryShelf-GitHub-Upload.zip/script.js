const stories = [
  {
    "title": "The Lost Kingdom",
    "language": "English",
    "genre": "Fantasy",
    "author": "Mira Santos",
    "synopsis": "A map leads Lina to a forgotten kingdom where kindness matters more than a crown.",
    "chapter": "The Map Beneath the Floorboards",
    "content": [
      "Lina found a yellow map beneath a loose floorboard. It led her beyond the hills to a quiet kingdom. The gardens were dry and the people had lost hope. Lina returned a crown she found instead of keeping it. Her kindness brought the villagers together again. She learned that the greatest treasure is a place you help make better."
    ]
  },
  {
    "title": "A Letter for Tomorrow",
    "language": "English",
    "genre": "Drama",
    "author": "Noah Reyes",
    "synopsis": "An unfinished letter changes how Daniel sees his father and his future.",
    "chapter": "The Unsent Letter",
    "content": [
      "Daniel found an envelope with his name in his father’s handwriting. It described a dream Daniel had been afraid to share: becoming an artist. His father admitted he wanted Daniel to choose a path that made him feel alive. Daniel wrote a letter of his own, explaining his hopes and fears. Tomorrow no longer seemed distant; it was a page he could begin writing today."
    ]
  },
  {
    "title": "The Little Coffee Shop",
    "language": "English",
    "genre": "Slice of Life",
    "author": "Ava Lim",
    "synopsis": "A small café becomes a meeting place for strangers who need hope.",
    "chapter": "A Table by the Window",
    "content": [
      "At a tiny coffee shop, a student who failed an exam, a musician who lost a job, and a tired nurse sat together during a rainy afternoon. When the power went out, they shared a flashlight, a song, and a funny story. Their troubles did not disappear, but the room felt warmer. Before leaving, each wrote an encouraging note for the next customer."
    ]
  },
  {
    "title": "Friends Until the End",
    "language": "English",
    "genre": "Friendship",
    "author": "Ethan Cruz",
    "synopsis": "Two friends learn that growing in different directions does not mean losing each other.",
    "chapter": "Different Roads",
    "content": [
      "Ben wanted to study music in the city, while Oliver planned to help his family’s farm. They worried their different choices would end their friendship. Before graduation, they exchanged a song and a small plant as reminders of their bond. They promised to make room for each other’s changing lives. Years later, they remained friends because friendship was a road they could always return to."
    ]
  },
  {
    "title": "The Secret Garden",
    "language": "English",
    "genre": "Mystery",
    "author": "Isla Morgan",
    "synopsis": "A locked garden and a trail of notes lead two siblings to a family secret.",
    "chapter": "The Gate in the Ivy",
    "content": [
      "June and Peter found a gate hidden by ivy. A trail of notes led them to a garden with a bench carved with their grandmother’s initials. Their grandmother explained that she had planted it with a childhood friend before life separated them. The secret was not frightening; it was a memory waiting to be found."
    ]
  },
  {
    "title": "Dreams Beyond the Stars",
    "language": "English",
    "genre": "Science Fiction",
    "author": "Leo Navarro",
    "synopsis": "A young inventor sends a message into space and receives an unexpected answer.",
    "chapter": "A Signal of Hope",
    "content": [
      "Amara built a radio from spare wires and old toy parts. One night, strange pulses appeared on her screen. She shared the recording with an observatory and learned the signal came from a natural source. It was not proof of life beyond Earth, but it helped scientists study faint signals. Amara’s dream changed from simply finding aliens to understanding the stars."
    ]
  },
  {
    "title": "The Honest Merchant",
    "language": "English",
    "genre": "Moral Story",
    "author": "Maya Flores",
    "synopsis": "A market seller discovers that honesty builds trust longer than quick profit.",
    "chapter": "The Extra Coin",
    "content": [
      "Mr. Arun found an extra coin after a customer hurried away. His assistant suggested keeping it, but Mr. Arun set it aside. The worried customer returned at noon, and he gave it back. She told others about his honesty, and more people visited his stall. He did not become rich overnight, but he built a good name and slept peacefully."
    ]
  },
  {
    "title": "The Last Tree",
    "language": "English",
    "genre": "Environmental",
    "author": "Sofia Chen",
    "synopsis": "A neighborhood works together to save the last old tree on its street.",
    "chapter": "Roots of Change",
    "content": [
      "An old acacia was marked for removal to make room for parking. Student Priya gathered photographs and signatures and spoke at a community meeting. Neighbors suggested a revised plan that protected the tree’s roots. The acacia remained, and people planted flowers around it. They learned that a shared home needs shared responsibility."
    ]
  },
  {
    "title": "A Second Chance",
    "language": "English",
    "genre": "Inspirational",
    "author": "Caleb Torres",
    "synopsis": "A student learns to repair trust after a mistake on a group project.",
    "chapter": "Starting Again",
    "content": [
      "Riley forgot to submit the final file for a group project. Instead of making excuses, Riley admitted the mistake and offered to organize the next presentation. Some teammates stayed upset, and Riley understood why. Riley worked carefully and kept everyone updated. Over time, trust returned because a second chance was supported by better actions."
    ]
  },
  {
    "title": "The Clockmaker's Secret",
    "language": "English",
    "genre": "Mystery",
    "author": "Oliver King",
    "synopsis": "A stopped clock leads an apprentice to a message hidden by a master clockmaker.",
    "chapter": "At Six O’Clock",
    "content": [
      "Nora noticed that one wooden clock in Mr. Vale’s shop always stopped at six. While repairing it, she found a photograph of Mr. Vale as a young apprentice. He explained that the clock had belonged to the teacher who taught him patience and craftsmanship. Nora repaired it and left the note inside for the next curious apprentice."
    ]
  },
  {
    "title": "The Brave Little Sparrow",
    "language": "English",
    "genre": "Adventure",
    "author": "Nina Patel",
    "synopsis": "A small sparrow discovers that courage means helping even while afraid.",
    "chapter": "Across the Storm",
    "content": [
      "Pip was the smallest sparrow in the garden. During a storm, he noticed a young bird stranded on a low branch. Afraid of the wind, Pip carefully followed the fence post by post and guided the bird toward shelter. Other sparrows came to help. Pip learned that bravery does not mean feeling no fear; it means finding a careful way to help."
    ]
  },
  {
    "title": "The Unopened Gift",
    "language": "English",
    "genre": "Family",
    "author": "Grace Villanueva",
    "synopsis": "A forgotten birthday present reveals the meaning behind a family tradition.",
    "chapter": "Wrapped in Blue",
    "content": [
      "Every birthday, Grandma gave Ella a small blue box. One year, Ella forgot to open it. Inside were notes describing memories from every birthday since she was born. The final note said, “I hope you notice the love in ordinary moments.” Ella read every note beside her grandmother and realized the box held years of someone paying attention."
    ]
  },
  {
    "title": "Beyond the Finish Line",
    "language": "English",
    "genre": "Sports",
    "author": "Jordan Lee",
    "synopsis": "A runner learns that the most meaningful victory can happen after a race.",
    "chapter": "The Last Lap",
    "content": [
      "Marcus trained all year for a school race. Near the final lap, he saw a younger runner hurt beside the track. Marcus called for help and stayed until a teacher arrived, losing his chance at a medal. His teammates later chose him to lead practice because they had seen his character. He learned that character matters beyond the finish line."
    ]
  },
  {
    "title": "The Village of Lanterns",
    "language": "English",
    "genre": "Fantasy",
    "author": "Amelia Brooks",
    "synopsis": "A child reminds a village that hope can be shared without spending much money.",
    "chapter": "Light the Way",
    "content": [
      "After a difficult harvest, the village planned to cancel its lantern festival. Wren made a lantern from a used jar and placed it in her window with an encouraging note. Neighbors made their own lanterns from reused materials and shared food with one another. The street glowed that evening. Wren showed them that hope does not need to be costly to be shared."
    ]
  },
  {
    "title": "The Power of One Voice",
    "language": "English",
    "genre": "School Life",
    "author": "Samuel Ortiz",
    "synopsis": "A quiet student inspires classmates to care for their school garden.",
    "chapter": "The Classroom Promise",
    "content": [
      "Ana noticed litter in the school garden but feared speaking up. She finally shared her concern with the class. One student suggested labeled bins, another made posters, and their teacher organized a garden-care schedule. After a month, the garden looked better. Ana learned that one voice can start a conversation and many voices can turn it into action."
    ]
  },
  {
    "title": "Ang Batang May Pangarap",
    "language": "Tagalog",
    "genre": "Inspirational",
    "author": "ChatGPT — Orihinal na Kuwento",
    "synopsis": "Isang batang mahilig gumuhit ang nagsisikap abutin ang pangarap sa kabila ng pagsubok.",
    "chapter": "Ang Munting Kuwaderno",
    "content": [
      "Si Lino ay mahilig gumuhit ng mga bahay, tulay, at gusali. Pangarap niyang maging arkitekto balang araw. May mga taong nagsabing masyadong malaki ang pangarap niya, ngunit patuloy siyang nag-aral at humingi ng payo sa guro. Sumali siya sa paligsahan ng disenyo at nakatanggap ng pagkilala. Natutuhan niyang kailangang samahan ng sipag at paniniwala ang pangarap."
    ]
  },
  {
    "title": "Ang Nawawalang Pitaka",
    "language": "Tagalog",
    "genre": "Moral Story",
    "author": "ChatGPT — Orihinal na Kuwento",
    "synopsis": "Nakakita si Ben ng pitaka at kailangang pumili sa pagitan ng pansariling kagustuhan at katapatan.",
    "chapter": "Ang Tamang Desisyon",
    "content": [
      "Habang pauwi, nakakita si Ben ng pitakang may pera at kard ng may-ari. Kailangan niya ng pera para sa proyekto kaya natukso siyang gamitin ito. Naalala niya ang payo ng ina at ibinalik ang pitaka sa may-ari. Nagpasalamat ang lalaki. Umuwi si Ben na walang dagdag na pera ngunit magaan ang pakiramdam dahil ginawa niya ang tama."
    ]
  },
  {
    "title": "Ang Lumang Punong Mangga",
    "language": "Tagalog",
    "genre": "Family",
    "author": "ChatGPT — Orihinal na Kuwento",
    "synopsis": "Nais putulin ang lumang puno hanggang maalala ng pamilya ang mga alaalang nakaugnay rito.",
    "chapter": "Mga Alaalang Nakasabit",
    "content": [
      "Sa bakuran ng pamilya Reyes ay may lumang punong mangga kung saan naglaro ang magkakapatid at nagpahinga ang kanilang lolo. Nais itong putulin upang lumaki ang garahe, ngunit ipinakita ni Mara ang mga lumang litrato sa ilalim nito. Naalala ng pamilya ang mga kaarawan at kuwentuhan. Humanap sila ng ibang paraan at pinanatili ang puno."
    ]
  },
  {
    "title": "Liham Para kay Nanay",
    "language": "Tagalog",
    "genre": "Drama",
    "author": "ChatGPT — Orihinal na Kuwento",
    "synopsis": "Sumulat ang isang anak ng liham upang masabi ang pasasalamat na nahihiya siyang sabihin nang harapan.",
    "chapter": "Mga Salitang Hindi Nasabi",
    "content": [
      "Abala si Nico sa pag-aaral at madalas maikli ang sagot sa kaniyang nanay. Isang gabi, nakita niyang nakatulog ito matapos maghanda ng pagkain at mag-ayos ng gamit. Napansin niya ang pagod at mga sakripisyong hindi niya napapansin. Sumulat siya ng liham ng pasasalamat at iniwan ito sa mesa. Kinabukasan, niyakap niya ang kaniyang nanay at nagsimulang tumulong sa bahay."
    ]
  },
  {
    "title": "Ang Matalinong Magsasaka",
    "language": "Tagalog",
    "genre": "Moral Story",
    "author": "ChatGPT — Orihinal na Kuwento",
    "synopsis": "Gumamit ang isang magsasaka ng talino at pagtutulungan upang malampasan ang kakulangan sa tubig.",
    "chapter": "Tubig Para sa Bukid",
    "content": [
      "Matagal na hindi umulan sa baryo ni Mang Tino. Natutuyo ang mga tanim kaya gumawa siya ng maliliit na kanal at naglagay ng tuyong dahon sa paligid ng mga halaman. Ibinahagi niya ang paraan sa mga kapitbahay at sama-sama nilang inayos ang daluyan ng tubig. Nang dumating ang tag-ulan, mas handa ang baryo. Natutuhan nilang mas kapaki-pakinabang ang talino kapag ibinabahagi."
    ]
  },
  {
    "title": "Ang Kaibigang Tunay",
    "language": "Tagalog",
    "genre": "Friendship",
    "author": "ChatGPT — Orihinal na Kuwento",
    "synopsis": "Natutuhan ni Ella na ang tunay na kaibigan ay nagbibigay rin ng tapat na payo.",
    "chapter": "Sa Oras ng Pangangailangan",
    "content": [
      "Magkaibigan sina Ella at Bea mula elementarya. Akala ni Ella, dapat laging sumasang-ayon ang kaibigan. Nang piliin niyang hindi mag-aral para sa pagsusulit, pinaalalahanan siya ni Bea at nagalit si Ella. Nang bumaba ang marka niya, tinulungan siya ni Bea gumawa ng iskedyul. Humingi ng tawad si Ella at naunawaang ang tunay na kaibigan ay nagsasabi ng totoo dahil nagmamalasakit."
    ]
  },
  {
    "title": "Ang Munting Tindahan",
    "language": "Tagalog",
    "genre": "Community",
    "author": "ChatGPT — Orihinal na Kuwento",
    "synopsis": "Pinag-isa ng maliit na tindahan ang mga kapitbahay sa pamamagitan ng simpleng kabutihan.",
    "chapter": "Tindahan ni Aling Rosa",
    "content": [
      "May maliit na tindahan si Aling Rosa sa kanto. Nang magkasakit ang matandang kapitbahay na mag-isang nakatira, hinikayat niya ang mga kapitbahay na tumulong. May nagluto, may nagdala ng pangangailangan, at may naglinis ng bakuran. Nang gumaling ang matanda, nagpasalamat siya. Naging daan ang tindahan upang maalala ng komunidad na ang malasakit ay nagsisimula sa simpleng pagtulong."
    ]
  },
  {
    "title": "Ang Lihim ng Silid-Aklatan",
    "language": "Tagalog",
    "genre": "Mystery",
    "author": "ChatGPT — Orihinal na Kuwento",
    "synopsis": "Isang lumang aklat ang naghatid sa magkaklase sa lihim tungkol sa kasaysayan ng paaralan.",
    "chapter": "Ang Aklat na Walang Pamagat",
    "content": [
      "Habang naglilinis ng silid-aklatan, nakita ni Carlo ang lumang aklat na walang pamagat at may mga guhit ng paaralan. Kasama si Mina, sinundan niya ang mga pahiwatig hanggang sa kahon ng lumang larawan. Nandoon ang unang mga mag-aaral na nagtanim ng puno bilang pag-alala sa mga guro. Ipinakita nila ang natuklasan sa klase at gumawa ng eksibit tungkol sa kasaysayan ng paaralan."
    ]
  },
  {
    "title": "Ang Sapatos ni Marco",
    "language": "Tagalog",
    "genre": "Inspirational",
    "author": "ChatGPT — Orihinal na Kuwento",
    "synopsis": "Nahihiya si Marco sa kaniyang lumang sapatos hanggang matuklasan niya ang halaga ng pagsisikap.",
    "chapter": "Bawat Hakbang",
    "content": [
      "Nahihiya si Marco sa luma niyang sapatos kaya nag-atubili siyang sumali sa takbuhan. Sinabi ng kuya niya na hindi sapatos ang magpapasya sa kaniyang kakayahan. Nagsanay si Marco tuwing hapon. Hindi siya nanalo sa unang puwesto, ngunit natapos niya ang takbuhan at ipinagmalaki ang sarili. Natutuhan niyang ang pagsisikap ay mas mahalaga kaysa mamahaling gamit."
    ]
  },
  {
    "title": "Ang Araw ng Pag-asa",
    "language": "Tagalog",
    "genre": "Drama",
    "author": "ChatGPT — Orihinal na Kuwento",
    "synopsis": "Nagtulungan ang isang pamilya upang muling maniwala sa bukas matapos mapinsala ng ulan ang kanilang bahay.",
    "chapter": "Pagkatapos ng Ulan",
    "content": [
      "Matapos ang malakas na ulan, napinsala ang bahay ng pamilya ni Ana. Kinabukasan, dumating ang mga kapitbahay na may dalang walis, damit, at pagkain. Sama-sama nilang inayos ang bubong at nilinis ang bahay. Gumawa si Ana ng listahan ng mga bagay na kaya nilang ayusin bawat araw. Natutuhan niyang ang pag-asa ay hindi lamang paghihintay kundi pagkilos habang may problema."
    ]
  },
  {
    "title": "Ang Parol ng Barangay",
    "language": "Tagalog",
    "genre": "Community",
    "author": "ChatGPT — Orihinal na Kuwento",
    "synopsis": "Nagkaisa ang mga kapitbahay upang gumawa ng parol mula sa recycled na materyales.",
    "chapter": "Liwanag Mula sa Pagkakaisa",
    "content": [
      "Kaunti ang pondo ng barangay para sa palamuti sa Pasko. Gumamit ang mga bata ng lumang bote, karton, at makukulay na papel upang gumawa ng parol. Tumulong ang matatanda sa pagbuo at ang kabataan sa pag-aayos ng ligtas na ilaw. Nang sindihan ang mga parol, napuno ng saya ang plaza. Ipinakita nilang ang pagkamalikhain at pagkakaisa ay kayang lumikha ng kagandahan."
    ]
  },
  {
    "title": "Ang Pangarap ni Aling Cora",
    "language": "Tagalog",
    "genre": "Inspirational",
    "author": "ChatGPT — Orihinal na Kuwento",
    "synopsis": "Sa kabila ng edad, sinimulan ni Aling Cora ang pangarap na matutong magbasa nang mas mahusay.",
    "chapter": "Hindi Pa Huli",
    "content": [
      "Buong buhay na nagtrabaho si Aling Cora sa palengke. Marunong siyang magbilang ngunit nahihirapang basahin ang mahahabang karatula. Sumali siya sa libreng klase sa barangay at nagsanay tuwing gabi. Sa pagtatapos, nabasa niya nang mag-isa ang liham ng kaniyang apo. Natutuhan niyang hindi nasusukat sa edad ang kakayahang matuto at hindi nakakahiya ang magsimula."
    ]
  },
  {
    "title": "Ang Batang Tagapangalaga ng Ilog",
    "language": "Tagalog",
    "genre": "Environmental",
    "author": "ChatGPT — Orihinal na Kuwento",
    "synopsis": "Nang makita ni Paolo ang maruming ilog, hinikayat niya ang barangay na pangalagaan ito.",
    "chapter": "Ilog na Buhay",
    "content": [
      "Napansin ni Paolo na dumami ang plastik at basura sa ilog na dinaraanan niya araw-araw. Nag-organisa ang kaniyang klase ng paglilinis, ngunit napagtanto nilang kailangan din ng tuloy-tuloy na pag-aalaga. Naglagay ang barangay ng basurahan at nagtakda ng iskedyul ng paglilinis. Pagkalipas ng ilang buwan, mas malinis ang pampang. Natutuhan nilang responsibilidad ng lahat ang kalikasan."
    ]
  },
  {
    "title": "Ang Huling Biyahe ng Dyip",
    "language": "Tagalog",
    "genre": "Slice of Life",
    "author": "ChatGPT — Orihinal na Kuwento",
    "synopsis": "Sa isang biyahe pauwi, natutuhan ng pasahero ang halaga ng kabutihan sa ordinaryong araw.",
    "chapter": "Sa Dulo ng Ruta",
    "content": [
      "Sumakay si Mika sa dyip pauwi matapos ang nakakapagod na klase. Nang muntik mahulog ang supot ng matandang katabi niya, tinulungan niya ito at hiniling sa drayber na huminto sa ligtas na tawiran. Nagpasalamat ang matanda at nagkuwento tungkol sa anak na bibisitahin. Nawala ang pagod ni Mika habang nakikinig. Natutuhan niyang nagiging makabuluhan ang ordinaryong araw kapag pinapansin natin ang ibang tao."
    ]
  },
  {
    "title": "Ang Boses ng Kabataan",
    "language": "Tagalog",
    "genre": "School Life",
    "author": "ChatGPT — Orihinal na Kuwento",
    "synopsis": "Natutuhan ng mga estudyante na magpahayag nang magalang at sama-sama upang mapabuti ang kanilang silid-aralan.",
    "chapter": "Pakinggan Kami",
    "content": [
      "Napansin ng mga estudyante na mainit ang silid-aralan dahil kulang ang bentilasyon. Gumawa si Rafi at ang mga kaklase niya ng liham na may mga mungkahi at pirma. Sa pulong kasama ang punong-guro, mahinahon nilang ipinaliwanag ang problema. Nangako ang paaralan na uunahin ang pagkukumpuni ng mga bentilador. Natutuhan nilang may halaga ang boses ng kabataan kapag ginagamit nang responsable at may paggalang."
    ]
  }
];

const grid=document.getElementById('grid'), search=document.getElementById('search'), genre=document.getElementById('genre'), sort=document.getElementById('sort'), reader=document.getElementById('reader');
let language='All'; const likes=new Set();
document.getElementById('year').textContent=new Date().getFullYear();
[...new Set(stories.map(s=>s.genre))].sort().forEach(g=>{let o=document.createElement('option');o.value=g;o.textContent=g;genre.appendChild(o)});
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function renderStories(){
 let list=stories.map((s,index)=>({...s,index})).filter(s=>(language==='All'||s.language===language)&&(genre.value==='All genres'||s.genre===genre.value)&&`${s.title} ${s.author} ${s.genre} ${s.synopsis} ${s.language}`.toLowerCase().includes(search.value.trim().toLowerCase()));
 if(sort.value==='title')list.sort((a,b)=>a.title.localeCompare(b.title)); if(sort.value==='genre')list.sort((a,b)=>a.genre.localeCompare(b.genre)||a.title.localeCompare(b.title));
 grid.innerHTML='';
 list.forEach(s=>{const card=document.createElement('article');card.className='card';let liked=likes.has(s.index);card.innerHTML=`<div class="cardtop"><span class="pill">${esc(s.language)}</span><button class="like ${liked?'liked':''}" aria-label="Like story">${liked?'♥':'♡'}</button></div><span class="pill">${esc(s.genre)}</span><h3>${esc(s.title)}</h3><p class="author">By ${esc(s.author)}</p><p class="synopsis-text">${esc(s.synopsis)}</p><div class="actions"><button class="read">Read story →</button><button class="synopsis-btn">Hide synopsis</button></div>`;
 card.querySelector('.read').onclick=()=>openStory(s.index);card.querySelector('.like').onclick=()=>{likes.has(s.index)?likes.delete(s.index):likes.add(s.index);renderStories()};card.querySelector('.synopsis-btn').onclick=e=>{let p=card.querySelector('.synopsis-text'),hide=p.classList.toggle('hidden');e.currentTarget.textContent=hide?'Show synopsis':'Hide synopsis'};grid.appendChild(card)});
 document.getElementById('count').textContent=`${list.length} ${list.length===1?'story':'stories'}`;document.getElementById('empty').classList.toggle('hidden',list.length>0);grid.classList.toggle('hidden',list.length===0);
}
function openStory(i){let s=stories[i];for(const [id,val] of Object.entries({rlang:s.language,rgenre:s.genre,rtitle:s.title,rauthor:`By ${s.author} · Original short story`,rsynopsis:s.synopsis,rchapter:s.chapter}))document.getElementById(id).textContent=val;document.getElementById('content').innerHTML=s.content.map(p=>`<p>${esc(p)}</p>`).join('');reader.scrollTop=0;document.getElementById('bar').style.width='0%';document.getElementById('percent').textContent='0%';reader.showModal()}
search.addEventListener('input',renderStories);genre.addEventListener('change',renderStories);sort.addEventListener('change',renderStories);
document.querySelectorAll('[data-lang]').forEach(b=>b.onclick=()=>{language=b.dataset.lang;document.querySelectorAll('[data-lang]').forEach(x=>x.classList.toggle('chosen',x===b));renderStories()});
document.getElementById('reset').onclick=()=>{search.value='';genre.value='All genres';sort.value='featured';language='All';document.querySelectorAll('[data-lang]').forEach(b=>b.classList.toggle('chosen',b.dataset.lang==='All'));renderStories()};
document.getElementById('theme').onclick=()=>{let dark=document.body.classList.toggle('dark');document.getElementById('theme').textContent=dark?'☀️ Light mode':'🌙 Dark mode'};
document.getElementById('close').onclick=()=>reader.close();document.getElementById('finish').onclick=()=>reader.close();reader.addEventListener('click',e=>{if(e.target===reader)reader.close()});
reader.addEventListener('scroll',()=>{let max=reader.scrollHeight-reader.clientHeight,p=max>0?Math.round(reader.scrollTop/max*100):100;document.getElementById('bar').style.width=p+'%';document.getElementById('percent').textContent=p+'%'});
const menu=document.getElementById('menu'),nav=document.getElementById('nav');menu.onclick=()=>nav.classList.toggle('open');nav.querySelectorAll('a').forEach(a=>a.onclick=()=>nav.classList.remove('open'));
document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();search.focus();document.getElementById('library').scrollIntoView({behavior:'smooth'})}});
renderStories();
